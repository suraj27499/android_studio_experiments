package com.example.exp3;



import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MyArrayAdapter extends ArrayAdapter<String> {
    Activity context;
    public int[] imageids;
    public String[] names;
    public String[] prices;
    MyArrayAdapter(Activity context,int[] imageids,String[] names,String[] prices){
        super(context,R.layout.customlayout,names);
        this.imageids=imageids;
        this.names=names;
        this.prices=prices;
        this.context=context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View myview=inflater.inflate(R.layout.customlayout,null);
        ImageView imageView=myview.findViewById(R.id.im1);
        TextView textview1=myview.findViewById(R.id.tv1);
        TextView textview2=myview.findViewById(R.id.tv2);

        imageView.setImageResource(imageids[position]);
        textview1.setText(names[position]);
        textview2.setText("Rs. "+prices[position]);
        return myview;
    }
}//