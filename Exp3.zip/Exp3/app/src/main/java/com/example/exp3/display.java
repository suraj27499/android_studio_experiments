package com.example.exp3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class display extends AppCompatActivity {

    TextView outputbox1;
    TextView outputbox2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        outputbox1 = findViewById(R.id.items);
        outputbox2 = findViewById(R.id.values);
        List<String> b;

        List<String> c;
        Intent recintent = getIntent();
        Bundle extras = recintent.getExtras();
        b=extras.getStringArrayList("bill");
        c = extras.getStringArrayList("prices");
        /*ArrayList to Array Conversion */
        String array[] = new String[b.size()];
        String array2[] = new String[c.size()];
        for(int j =0;j<b.size();j++){
            array[j] = b.get(j);

        }
        for(int v =0;v<c.size();v++){
            array2[v] =c.get(v);

        }
        String x="";
        String y="";
        for (String i: array){
            x+=i+"\n";
        }

        x=x+"\n"+"-------------------"+"\n"+"Total";
        for (String h: array2){
            y+="\u20B9"+" "+h+"\n";
        }
        int z=0;
        for(int r=0;r<array2.length;r++){
            z=z+Integer.parseInt(array2[r]);
        }
        y=y+"\n"+"---------"+"\n"+"\u20B9"+" "+z;


        outputbox1.setText(x);
        outputbox2.setText(y);
    }
}
