package com.example.exp3;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    ListView mylist;
    TextView icon;
    public int[] imageids={R.drawable.apple,R.drawable.banana,R.drawable.mango,R.drawable.pear,R.drawable.orange};
    public String[] names={"Apple","Banana","Mango","Pear","Orange"};
    public String[] prices={"200","220","250","260","300"};

    public List<String> billProducts = new ArrayList<String>();
    public List<String> bills = new ArrayList<String>();
    int counter = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mylist=findViewById(R.id.mylistview);
        Button cartBtn = findViewById(R.id.cart);

        cartBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this,display.class);
                myIntent.putExtra("bill", (ArrayList<String>) billProducts);
                myIntent.putExtra("prices", (ArrayList<String>) bills);

                startActivity(myIntent);
            }
        });
        final MyArrayAdapter myarrayadapter=new MyArrayAdapter(this,imageids,names,prices);
        mylist.setAdapter(myarrayadapter);
        mylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                icon = (TextView)findViewById(R.id.mark);
                String in=myarrayadapter.getItem(position);
                final int i=position;
                counter++;
                icon.setText(String.valueOf(counter));


                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                builder.setMessage(in+" has been selected")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener(){

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                billProducts.add(names[i]);
                                bills.add(prices[i]);

                            }
                        })
                        .setNegativeButton("CANCEL",null);
                AlertDialog alert=builder.create();
                alert.show();


            }
        });
    }
}
