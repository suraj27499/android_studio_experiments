# Banker
An application following mvvm model and implementing room database,with CRUD operations. 




In collabration,
[@Suraj Kumar](https://github.com/suraj27499)
[@Samuel Rajasingh](https://github.com/samuelrajasingh)
