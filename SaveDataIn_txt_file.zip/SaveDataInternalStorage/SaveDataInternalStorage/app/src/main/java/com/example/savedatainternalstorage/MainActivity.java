package com.example.savedatainternalstorage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.Buffer;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    TextView textView;
    public static final String filename = "arul.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.edit_text);
        textView = findViewById(R.id.text_view);
    }
    public void save(View view)
    {
        String data=editText.getText().toString();
        FileOutputStream fos = null;
        try {
            fos = openFileOutput(filename,MODE_PRIVATE);
            fos.write(data.getBytes());
           // OutputStreamWriter osw = new OutputStreamWriter(fos);
            //osw.write(data);
            String outmsg="Data Saved "+getFilesDir()+"/"+filename;
            Toast toast= Toast.makeText(this,outmsg,Toast.LENGTH_LONG);
            toast.setGravity(Gravity.BOTTOM,0,50);
            toast.show();
        }catch(Exception e){
            e.printStackTrace();
        }

    }
    public void load(View view) {
        FileInputStream fis=null;
        try {
            fis=openFileInput(filename);
            InputStreamReader isr=new InputStreamReader(fis);
            BufferedReader br=new BufferedReader(isr);
            //StringBuilder sb=new StringBuilder();
            String output = "";
            String text;
            while((text=br.readLine())!=null){
                output = output + text + "\n";
                //sb.append(text).append("\n");
            }
            //textView.setText(sb.toString());
            textView.setText(output);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}