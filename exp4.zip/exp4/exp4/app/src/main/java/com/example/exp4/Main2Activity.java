package com.example.exp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class Main2Activity extends AppCompatActivity {
    DbHelper db;
    Button login ;
    EditText user , pass;
    Intent myintent2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        login = findViewById(R.id.login);
        user = findViewById(R.id.logname);
        pass = findViewById(R.id.logpass);
        myintent2 = new Intent(getApplicationContext(),display.class);
        db= new DbHelper(Main2Activity.this,"colleges",null,1);
        login.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String userName = user.getText().toString();
                        String password = pass.getText().toString();

                        String status = db.login(userName, password);
                        if (status.equals("no")) {

                            //Toast.makeText(getApplicationContext(), " Try Again!", Toast.LENGTH_SHORT).show();
                           // Snackbar.make(findViewById(R.id.xyz), " Failed", Snackbar.LENGTH_SHORT).show();
                            Snackbar sb = Snackbar.make(findViewById(R.id.xyz), "Login Failed ", Snackbar.LENGTH_SHORT);
                            sb.setTextColor(Color.rgb(200,100,100));
                            sb.setBackgroundTint(Color.rgb(20,100,200));
                            sb.show();

                            //Log.d("TAG", "no of users : "+status);
                        }else{

                            //Toast.makeText(getApplicationContext(), "Logged in", Toast.LENGTH_SHORT).show();
                            myintent2.putExtra("o",status);
                            startActivity(myintent2);
                        }
                    }
                });
    }
}
