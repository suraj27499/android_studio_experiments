package com.example.exp4;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    String out="";
    public DbHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //String query = "create table users(name varchar(20),mobile varchar(20))";
        String query = "create table users(email varchar(20),password varchar(20),phone varchar(20),name varchar(20))";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query="drop table if exists users";
        db.execSQL(query);
        onCreate(db);
    }
    //saveData
    public long saveData(String email,String password,String phone,String name){

        SQLiteDatabase db= getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("EMAIL",email);
        cv.put("PASSWORD",password);
        cv.put("PHONE",phone);
        cv.put("NAME",name);
        long recds= db.insert("users",null,cv);
        return recds;
    }
    //display
    public String display(String mail){
        SQLiteDatabase db =getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from users where email='"+mail+"'",null);

        while (cursor.moveToNext()){
            String email= cursor.getString(0);
            String pass= cursor.getString(1);
            String phone= cursor.getString(2);
            String name = cursor.getString(3);
            out=out+"EMAIL--------"+email+"\n\n"+"PASSWORD--------"+pass+"\n\n"+"PHONE--------"+phone+"\n\n"+"NAME--------"+name;
        }
        return out;


    }
    //chek whether userData exist
    public String login(String email,String pass){
        SQLiteDatabase db =getReadableDatabase();
       // Cursor cursor1="Select * from " + " where " + dbfield + " = " + fieldValue;
        Cursor cursor=db.rawQuery("select * from users where email='"+email+"' and password='"+pass+"'",null);
       // Cursor cursor=db.rawQuery("Select * from users" + " where " + name + " = " + ,null);

        if(cursor.getCount() <= 0){
            cursor.close();
            return "no";
        }
        cursor.close();
        return display(email);

    }
}
