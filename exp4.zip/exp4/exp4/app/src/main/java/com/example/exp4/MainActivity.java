package com.example.exp4;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    DbHelper db;
    Intent myintent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db= new DbHelper(MainActivity.this,"colleges",null,1);

        final EditText email = findViewById(R.id.email);
        final EditText password = findViewById(R.id.password);
        final EditText phone = findViewById(R.id.phone);
        final EditText name = findViewById(R.id.name);
        Button signup = findViewById(R.id.signup);
       // Button viewAll = findViewById(R.id.view_all);
        Button login = findViewById(R.id.login1);
        //final TextView outView = findViewById(R.id.outView);
         myintent = new Intent(getApplicationContext(),Main2Activity.class);
        signup.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String u = email.getText().toString();
                        String  p= password.getText().toString();
                        String ph = phone.getText().toString();
                        String n = name.getText().toString();

                        long status = db.saveData(u,p,ph,n);
                        if (status > 0) {
                           // Toast.makeText(getApplicationContext(), "Signup Successful", Toast.LENGTH_SHORT).show();
                            Snackbar.make(v, "Signup Successful", Snackbar.LENGTH_SHORT).show();
                            startActivity(myintent);
                            //Log.d("TAG", "no of users : "+status);
                        }else{
                            //Toast.makeText(getApplicationContext(), "Signup Failed. Try Again!", Toast.LENGTH_SHORT).show();
                            Snackbar.make(v, "Signup Failed", Snackbar.LENGTH_SHORT).show();

                        }
                    }
                });
        login.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(myintent);
                    }
                });
    }
}
