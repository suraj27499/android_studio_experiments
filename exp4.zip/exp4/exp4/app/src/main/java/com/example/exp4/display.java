package com.example.exp4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class display extends AppCompatActivity {
    TextView outputbox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        outputbox = findViewById(R.id.output);

        Intent recintent = getIntent();
        Bundle extras = recintent.getExtras();

        String outputtext =  extras.getString("o") ;

        outputbox.setText(outputtext);
    }
}
