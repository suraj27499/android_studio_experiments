package com.example.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    ListView listView;
    String music[]={"Drums Sound","Song"};
    int music_values[]={R.raw.sample1,R.raw.sample2};
    Button play,pause,stop;
    static int id=-1;
    MediaPlayer mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView=findViewById(R.id.mylistview);
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,music);
        listView.setAdapter(arrayAdapter);
        play=findViewById(R.id.play);
        pause=findViewById(R.id.pause);
        stop=findViewById(R.id.stop);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id1) {
                id=position;
                mp=MediaPlayer.create(getApplicationContext(),music_values[id]);
                Toast.makeText(getApplicationContext(),"You can play your song now",Toast.LENGTH_LONG).show();
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println(id);
                if(id==-1) {
                    Toast.makeText(getApplicationContext(), "Please select the song", Toast.LENGTH_LONG).show();
                    return;
                }
                mp.start();
            }
        });
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(id==-1) {
                    Toast.makeText(getApplicationContext(), "Please select the song", Toast.LENGTH_LONG).show();
                    return;
                }
                mp.pause();
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(id==-1){
                    Toast.makeText(getApplicationContext(),"Please select the song",Toast.LENGTH_LONG).show();
                    return;
                }
                mp.stop();
            }
        });


    }
}