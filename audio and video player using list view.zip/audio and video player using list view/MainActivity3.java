package com.example.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity3 extends AppCompatActivity {
    ListView listView;
    VideoView videoView;
    String Videos[]={"Nature Video","CSK video"};
    int Videovalues[]={R.raw.video1,R.raw.video2};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        listView=findViewById(R.id.listview);
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,Videos);
        listView.setAdapter(arrayAdapter);
        videoView=findViewById(R.id.videoview);
        videoView.setMediaController(new MediaController(this));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Uri uri=Uri.parse("android.resource://"+getPackageName()+"/"+Videovalues[position]);
                videoView.setVideoURI(uri);
                videoView.start();
            }
        });
    }
}