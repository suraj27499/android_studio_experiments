package com.example.exp9;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.accessibilityservice.GestureDescription;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    Button show;
    public static final int PICK_CODE = 0;
    EditText phonetext;
    String namedata=" ";
    String number="";
    EditText message;
    Button send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        show=findViewById(R.id.show);
        phonetext=findViewById(R.id.phonetext);
        message=findViewById(R.id.message);
        send=findViewById(R.id.send);
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
                startActivityForResult(intent,PICK_CODE);
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number=phonetext.getText().toString();
                String x=message.getText().toString();
                Intent intent=new Intent(getApplicationContext(),MainActivity2.class);
                PendingIntent pendingIntent=PendingIntent.getActivity(getApplicationContext(),1,intent,0);
                SmsManager smsManager=SmsManager.getDefault();
                String m="Hello "+namedata+","+x;
                smsManager.sendTextMessage(number,null,m,pendingIntent,null);
                Toast.makeText(getApplicationContext(),"sent message",Toast.LENGTH_LONG);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==PICK_CODE && resultCode == RESULT_OK){
            Uri uri = data.getData();
            Cursor cursor = getContentResolver().query(uri,null,null,null,null);
            if(cursor!=null && cursor.moveToFirst()){
                namedata = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                number =cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            }
            phonetext.setText(number);
        }
    }

}


