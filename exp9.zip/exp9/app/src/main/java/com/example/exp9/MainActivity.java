package com.example.exp9;



import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText number;
    EditText otp;
    static  String otpgenerated="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS}, PackageManager.PERMISSION_GRANTED);
        number=findViewById(R.id.number);
        otp=findViewById(R.id.otp);
    }

    public void getotp(View view) {
        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
        PendingIntent pendingIntent=PendingIntent.getActivity(getApplicationContext(),1,intent,0);
        String phone=number.getText().toString();
        SmsManager smsManager=SmsManager.getDefault();
        Random r=new Random();
        int x=r.nextInt(9999);
        otpgenerated=String.format("%04d",x);
        smsManager.sendTextMessage(phone,null,"Your otp is:"+otpgenerated,pendingIntent,null);
        Toast.makeText(getApplicationContext(),"message sent",Toast.LENGTH_LONG).show();
    }

    public void login(View view) {
        String otpEntered=otp.getText().toString();
        if(otpEntered.equals(otpgenerated)){
            Intent intent=new Intent(getApplicationContext(),MainActivity2.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(getApplicationContext(),"invalid otp",Toast.LENGTH_LONG).show();
        }
    }
}