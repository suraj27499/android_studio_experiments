package com.example.exp10;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Address;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {
    EditText name;
    EditText mail;
    String s;
    public static String mailto;
    EditText otpgenerated;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.name);
        mail=findViewById(R.id.mail);
        otpgenerated=findViewById(R.id.password);
    }

    public void login(View view) {
        String otp=otpgenerated.getText().toString();
        if(otp.equals(s)){
            Intent intent=new Intent(getApplicationContext(),MainActivity2.class);
            startActivity(intent);
        }
    }

    public void register(View view) {
        String n = name.getText().toString();
        String e = mail.getText().toString();
        mailto=e;
        int a=new Random().nextInt(9999);
        s=String.format("%04d",a);
        Properties properties = new Properties();
        properties.put("mail.smtp.auth","true");
        properties.put("mail.smtp.starttls.enable","true");
        properties.put("mail.smtp.host","smtp.gmail.com");
        properties.put("mail.smtp.port","587");
        final String fromEmail="surajkumardubey27499@gmail.com";
        final String password="bhhjghetqgpnhyiu";
        Session session=Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail,password);
            }
        });
        try{
            final Message message= new MimeMessage(session);
            message.setFrom(new InternetAddress(fromEmail));
            message.addRecipient(Message.RecipientType.TO,new InternetAddress(e));
            message.setSubject("otp for app");
            message.setText("Your otp is"+s);
            AsyncTask asyncTask=new AsyncTask() {
                ProgressDialog progressDialog;
                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    progressDialog = new ProgressDialog(MainActivity.this);
                    progressDialog.setTitle("Email Client");
                    progressDialog.setMessage("sending mail");
                    progressDialog.show();
                }
                @Override
                protected Void doInBackground(Object... msgs) {
                    try {
                        Transport.send(message);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(Object o) {
                    super.onPostExecute(o);
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(),"Mail Sent Successfully",Toast.LENGTH_LONG).show();
                }
            };
            asyncTask.execute();
        } catch (AddressException exception) {
            exception.printStackTrace();
        } catch (MessagingException exception) {
            exception.printStackTrace();
        } ;


    }
}