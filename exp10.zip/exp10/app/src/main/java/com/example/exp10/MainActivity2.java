package com.example.exp10;



import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@SuppressWarnings("ALL")
public class MainActivity2 extends AppCompatActivity {
    CheckBox pizza;
    CheckBox burger;
    CheckBox french;
    CheckBox sand;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        pizza=findViewById(R.id.pizza);
        burger=findViewById(R.id.burger);
        french=findViewById(R.id.french);
        sand=findViewById(R.id.sandwich);
    }

    public void place(View view) {
        String message="";
        int bill=0;
        if(pizza.isChecked()){
            message+="pizza @ 200 ";
            bill+=200;
        }
        if(burger.isChecked()){
            message+="burger @ 80 ";
            bill+=80;
        }
        if(sand.isChecked()){
            message+="sandwich @ 80 ";
            bill+=80;
        }
        if(french.isChecked()){
            message+="french fries @ 80 ";
            bill+=100;
        }
        final String m=message;
        final int b=bill;
        Properties properties = new Properties();
        properties.put("mail.smtp.auth","true");
        properties.put("mail.smtp.starttls.enable","true");
        properties.put("mail.smtp.host","smtp.gmail.com");
        properties.put("mail.smtp.port","587");
        final String fromEmail="surajkumardubey27499@gmail.com";
        final String password="bhhjghetqgpnhyiu";
        Session session=Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail,password);
            }
        });
        try{
            final Message messagecontent= new MimeMessage(session);
            messagecontent.setFrom(new InternetAddress(fromEmail));
            messagecontent.addRecipient(Message.RecipientType.TO,new InternetAddress(MainActivity.mailto));
            messagecontent.setSubject("bill");
            messagecontent.setText(message+String.valueOf(bill));
            AsyncTask asyncTask=new AsyncTask() {
                ProgressDialog progressDialog;
                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    progressDialog = new ProgressDialog(MainActivity2.this);
                    progressDialog.setTitle("Email Client");
                    progressDialog.setMessage("sending mail");
                    progressDialog.show();
                }
                @Override
                protected Void doInBackground(Object... msgs) {
                    try {
                        Transport.send(messagecontent);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(Object o) {
                    super.onPostExecute(o);
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(),m+" total"+String.valueOf(b),Toast.LENGTH_LONG).show();
                }
            };
            asyncTask.execute();
        } catch (AddressException exception) {
            exception.printStackTrace();
        } catch (MessagingException exception) {
            exception.printStackTrace();
        } ;
    }
}