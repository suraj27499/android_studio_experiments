package com.example.exp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class display extends AppCompatActivity {

    TextView outputbox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        outputbox = findViewById(R.id.output);

        Intent recintent = getIntent();
        Bundle extras = recintent.getExtras();
        double cgpa = (Double.parseDouble(extras.getString("mark1"))+Double.parseDouble(extras.getString("mark2")))/200.00;
        String outputtext = "Name = " + extras.getString("name") +
                "\nLocation=" + extras.getString("state")+
                "\nHobbies:"+extras.getString("hobby")+
                "\nDepartment :" + extras.getString("department")+
                "\ncgpa = " + cgpa;
        outputbox.setText(outputtext);
    }
}
