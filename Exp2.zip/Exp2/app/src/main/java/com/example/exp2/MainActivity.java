package com.example.exp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    EditText mytextbox,myname,myregno,myhobbies,department,mymark1,mymark2;
    Spinner state;
    RadioGroup radioGroup;
    RadioButton mybutton;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myname = findViewById(R.id.name);
        myregno = findViewById(R.id.regno);
        myhobbies = findViewById(R.id.hobby);
        state = findViewById(R.id.location);
        department = findViewById(R.id.department);
        mymark1 = findViewById(R.id.mark1);
        mymark2 = findViewById(R.id.mark2);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup1);

       //mybutton =  (RadioButton) findViewById(selectedId);






    }
    public void myaction(View view){
        //int selectedId = radioGroup.getCheckedRadioButtonId();
        int radioButtonID = radioGroup.getCheckedRadioButtonId();
        mybutton = radioGroup.findViewById(radioButtonID);//yes sir
        String n = myname.getText().toString();
        String r = myregno.getText().toString();
        String h = myhobbies.getText().toString();
        String s = state.getSelectedItem().toString();
        String d = department.getText().toString();
        String m1 = mymark1.getText().toString();
        String m2 = mymark2.getText().toString();
        String g  = mybutton.getText().toString();



        Intent myintent = new Intent(getApplicationContext(),display.class);
        myintent.putExtra("name",n);
        myintent.putExtra("regno",r);
        myintent.putExtra("hobby",h);
        myintent.putExtra("state",s);
        myintent.putExtra("department",d);
        myintent.putExtra("mark1",m1);
        myintent.putExtra("mark2",m2);
        myintent.putExtra("gender",g);



        startActivity(myintent);

    }
}
