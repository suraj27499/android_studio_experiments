package com.example.sampleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bob=(Button)findViewById((R.id.button));
        final EditText weight=(EditText)findViewById(R.id.weight);
        final EditText height=(EditText) findViewById(R.id.height);
        bob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double myheight = Double.parseDouble(height.getText().toString());
                double myweight = Double.parseDouble(weight.getText().toString());
                double bmi = myweight/(myheight*myheight);
                String value = "";
                if(bmi>30.00){
                    value="obese";
                }else if(bmi>=25.00 && bmi<30.00){
                    value="overweight";
                }else if(bmi>=20.00 && bmi<25.00){
                    value="normal";
                }else if(bmi<20.00){
                    value="underweight";
                }

                Toast.makeText(getApplicationContext(),"Category :"+value, Toast.LENGTH_SHORT).show();

            }
        });
    }
}
