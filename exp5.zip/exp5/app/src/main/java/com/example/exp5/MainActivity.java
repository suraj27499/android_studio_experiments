package com.example.exp5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    EditText username,password;
    CheckBox checked;
    Intent myintent;
    SharedPreferences myprefs ;
    SharedPreferences.Editor editor;
    TextInputEditText t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myprefs  = getSharedPreferences("myprefs",MODE_PRIVATE);
       editor =  myprefs.edit();
        username = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);
        checked = findViewById(R.id.checkBox);
        myintent = new Intent(getApplicationContext(),display.class);

        if(myprefs.getBoolean("checked",false)){
            username.setText(myprefs.getString("email",""));
            password.setText(myprefs.getString("password",""));
            checked.setChecked(myprefs.getBoolean("checked",false));
        }



    }

    public void login(View view) {
        String name = username.getText().toString();
        String pass = password.getText().toString();
        Boolean isChecked = checked.isChecked();
        if((name.equals("suraj@gmail.com") && pass.equals("suraj")   ) || (name.equals("panda@gmail.com") && pass.equals("panda"))   ){
            editor.putString("email",name);
            editor.putString("password",pass);
            editor.putBoolean("checked",isChecked);
            editor.apply();
            startActivity(myintent);
        }else if(!isChecked){
            Toast.makeText(getApplicationContext(), "please check the remember me box", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
            Snackbar.make(findViewById(R.id.p), "Signup Failed", Snackbar.LENGTH_SHORT).show();

        }

    }
}