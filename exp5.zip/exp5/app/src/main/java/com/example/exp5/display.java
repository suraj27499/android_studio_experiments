package com.example.exp5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class display extends AppCompatActivity {
    SharedPreferences myprefs;
    SharedPreferences.Editor editor;
    String email;
    String password;
    TextView name;
    Spinner colour;
    ConstraintLayout cl;
    String color;
    Intent myintent ;
    Boolean isChecked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        myprefs = getSharedPreferences("myprefs",MODE_PRIVATE);
        colour = findViewById(R.id.location);//spinner
        cl = findViewById(R.id.setbgc);
        email = myprefs.getString("email","");
        password = myprefs.getString("password","");
        isChecked = myprefs.getBoolean("checked",false);
        editor = myprefs.edit();
        name = findViewById(R.id.setName);
        name.setText(email);
         color = myprefs.getString("color","");

        if(color.equals("red")){
            colour.setSelection(0);
           // cl.setBackgroundColor(Color.RED);

        }else if(color.equals("yellow")){
            colour.setSelection(1);
           // cl.setBackgroundColor(Color.YELLOW);

        }else if(color.equals("green")){
            colour.setSelection(3);
           // cl.setBackgroundColor(Color.GREEN);

        }else if(color.equals("blue")){
            colour.setSelection(2);
            //cl.setBackgroundColor(Color.BLUE);

        }



        colour.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                color = ((TextView)view).getText().toString();
                if(color.equals("red")){
                    cl.setBackgroundColor(Color.RED);
                    editor.putString("color",color);
                    editor.apply();
                }else if(color.equals("yellow")){
                    cl.setBackgroundColor(Color.YELLOW);
                    editor.putString("color",color);
                    editor.apply();
                }else if(color.equals("green")){
                    cl.setBackgroundColor(Color.GREEN);
                    editor.putString("color",color);
                    editor.apply();
                }else if(color.equals("blue")){
                    cl.setBackgroundColor(Color.BLUE);
                    editor.putString("color",color);
                    editor.apply();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

                cl.setBackgroundColor(Color.WHITE);
                editor.putString("color",color);
                editor.apply();
            }
        });




    }

    public void logout(View view) {
   myintent = new Intent(getApplicationContext(),MainActivity.class);
   startActivity(myintent);
    }
}
/*
<input type="file">
FileInputStream fi = new Fil("D:/")

 */